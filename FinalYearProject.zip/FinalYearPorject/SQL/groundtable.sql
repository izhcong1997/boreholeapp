-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Feb 01, 2017 at 08:52 AM
-- Server version: 5.6.33
-- PHP Version: 5.6.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `entries`
--

-- --------------------------------------------------------

--
-- Table structure for table `groundtable`
--

CREATE TABLE `groundtable` (
  `_ID` int(11) NOT NULL,
  `BoreholeID` varchar(255) NOT NULL,
  `Date` varchar(255) NOT NULL,
  `Time` varchar(255) NOT NULL,
  `WaterDepth` varchar(255) NOT NULL,
  `Flag` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `groundtable`
--

INSERT INTO `groundtable` (`_ID`, `BoreholeID`, `Date`, `Time`, `WaterDepth`, `Flag`) VALUES
(0, '5', '12-1-2016', '1.30', '33', 'no'),
(0, '5', '12-1-2016', '1.30', '33', 'no'),
(0, '5', '12-1-2016', '1.30', '33', 'no'),
(0, '5', '12-1-2016', '1.30', '33', 'no'),
(0, '5', '12-1-2016', '1.30', '33', 'no'),
(0, '5', '12-1-2016', '1.30', '33', 'no'),
(0, '5', '12-1-2016', '1.30', '33', 'no'),
(0, '5', '12-1-2016', '1.30', '33', 'no'),
(0, '5', '12-1-2016', '1.30', '33', 'no'),
(0, '5', '12-1-2016', '1.30', '33', 'no');s