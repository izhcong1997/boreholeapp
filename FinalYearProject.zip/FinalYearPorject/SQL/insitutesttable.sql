-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Feb 01, 2017 at 08:53 AM
-- Server version: 5.6.33
-- PHP Version: 5.6.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `entries`
--

-- --------------------------------------------------------

--
-- Table structure for table `insitutesttable`
--

CREATE TABLE `insitutesttable` (
  `_ID` int(11) NOT NULL,
  `BoreholeID` int(11) DEFAULT NULL,
  `TypeOfTest` varchar(255) NOT NULL,
  `TestNumber` varchar(255) NOT NULL,
  `StartDepth` double DEFAULT NULL,
  `EndDepth` double DEFAULT NULL,
  `n1values` varchar(255) NOT NULL,
  `n2values` varchar(255) NOT NULL,
  `n3values` varchar(255) NOT NULL,
  `n4values` varchar(255) NOT NULL,
  `n5values` varchar(255) NOT NULL,
  `n6values` varchar(255) NOT NULL,
  `Nvalue` varchar(255) NOT NULL,
  `PenetrationDepth` varchar(255) NOT NULL,
  `GeologicalClassification` varchar(255) NOT NULL,
  `Strength` varchar(255) NOT NULL,
  `StrengthOptional` varchar(255) NOT NULL,
  `Color` varchar(255) NOT NULL,
  `ColorOptional1` varchar(255) NOT NULL,
  `ColorOptional2` varchar(255) NOT NULL,
  `ColorOptional3` varchar(255) NOT NULL,
  `SoilName` varchar(255) NOT NULL,
  `SoilNameOptional` varchar(255) NOT NULL,
  `ClassifierWeathering` varchar(255) NOT NULL,
  `Formation` varchar(255) NOT NULL,
  `Picture` varchar(255) NOT NULL,
  `Remoulded` varchar(255) NOT NULL,
  `Undisturbed` varchar(255) NOT NULL,
  `Flag` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `insitutesttable`
--

INSERT INTO `insitutesttable` (`_ID`, `BoreholeID`, `TypeOfTest`, `TestNumber`, `StartDepth`, `EndDepth`, `n1values`, `n2values`, `n3values`, `n4values`, `n5values`, `n6values`, `Nvalue`, `PenetrationDepth`, `GeologicalClassification`, `Strength`, `StrengthOptional`, `Color`, `ColorOptional1`, `ColorOptional2`, `ColorOptional3`, `SoilName`, `SoilNameOptional`, `ClassifierWeathering`, `Formation`, `Picture`, `Remoulded`, `Undisturbed`, `Flag`) VALUES
(0, 5, 'hi mr sing', '', 98, 0, '599', '599', '59', '59', '59', '59', '', '59999', '59', '59', '59', '559', '59', '59', '59', '59', '59', 'hello boi', '59', '59', '59', '59', '59'),
(1, 12, 'pw', '1', 13, 14, '1', '1', '1', '1', '1', '1', '1', '13', 'soil', 'strong', '', 'brown', '', '', '', 'soil', '', 'rain', 'stable', '', 'yes', 'no', 'yes'),
(0, 5, 'hi mr sing', '', 98, 0, '599', '599', '59', '59', '59', '59', '', '59999', '59', '59', '59', '559', '59', '59', '59', '59', '59', 'hello boi', '59', '59', '59', '59', '59'),
(0, 5, 'hi mr sing', '', 98, 0, '599', '599', '59', '59', '59', '59', '', '59999', '59', '59', '59', '559', '59', '59', '59', '59', '59', 'hello boi', '59', '59', '59', '59', '59'),
(0, 5, 'hi mr sing', '', 98, 0, '599', '599', '59', '59', '59', '59', '', '59999', '59', '59', '59', '559', '59', '59', '59', '59', '59', 'hello boi', '59', '59', '59', '59', '59'),
(0, 5, 'hi mr sing', '', 98, 0, '599', '599', '59', '59', '59', '59', '', '59999', '59', '59', '59', '559', '59', '59', '59', '59', '59', 'hello boi', '59', '59', '59', '59', '59'),
(0, 5, 'hi mr sing', '', 98, 0, '599', '599', '59', '59', '59', '59', '', '59999', '59', '59', '59', '559', '59', '59', '59', '59', '59', 'hello boi', '59', '59', '59', '59', '59'),
(0, 5, 'quadrille is pinoyi', '', 0, 0, 'u', 'u', '4579', 'I', 'it', 'I', '', 'you', 'I', 'I', 'I', 'I', 'it', 'I', 'I', 'I', 'I', 'I', 'it', 'I', 'I', 'I', 'I'),
(0, 5, '1', '', 1, 1, '1', '1', '1', '1', '1', '1', '', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1');
