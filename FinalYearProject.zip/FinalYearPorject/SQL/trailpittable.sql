-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Feb 01, 2017 at 08:56 AM
-- Server version: 5.6.33
-- PHP Version: 5.6.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `entries`
--

-- --------------------------------------------------------

--
-- Table structure for table `trialpittable`
--

CREATE TABLE `trialpittable` (
  `_ID` int(11) NOT NULL,
  `BoreholeID` int(11) DEFAULT NULL,
  `StartDepth` double NOT NULL,
  `EndDepth` double NOT NULL,
  `GeologicalClassification` varchar(255) NOT NULL,
  `Strength` varchar(255) NOT NULL,
  `StrengthOptional` varchar(255) NOT NULL,
  `Color` varchar(255) NOT NULL,
  `ColorOptional1` varchar(255) NOT NULL,
  `ColorOptional2` varchar(255) NOT NULL,
  `ColorOptional3` varchar(255) NOT NULL,
  `SoilName` varchar(255) NOT NULL,
  `SoilNameOptional` varchar(255) NOT NULL,
  `ClassifierWeathering` varchar(255) NOT NULL,
  `Formation` varchar(255) NOT NULL,
  `Flag` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trialpittable`
--

INSERT INTO `trialpittable` (`_ID`, `BoreholeID`, `StartDepth`, `EndDepth`, `GeologicalClassification`, `Strength`, `StrengthOptional`, `Color`, `ColorOptional1`, `ColorOptional2`, `ColorOptional3`, `SoilName`, `SoilNameOptional`, `ClassifierWeathering`, `Formation`, `Flag`) VALUES
(0, 14, 13, 15, 'soil', 'strong', '', 'brown', '', '', '', 'iron', '', 'yes', 'stable', 0),
(0, 14, 13, 15, 'soil', 'strong', '', 'brown', '', '', '', 'iron', '', 'yes', 'stable', 0);