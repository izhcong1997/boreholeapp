-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Feb 01, 2017 at 08:55 AM
-- Server version: 5.6.33
-- PHP Version: 5.6.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `entries`
--

-- --------------------------------------------------------

--
-- Table structure for table `samplingtable`
--

CREATE TABLE `samplingtable` (
  `_ID` int(11) NOT NULL,
  `BoreholeID` int(11) DEFAULT NULL,
  `TypeOfSampling` text,
  `StartDepth` double DEFAULT NULL,
  `EndDepth` double DEFAULT NULL,
  `ATT` text,
  `GeologicalClassification` text,
  `Strength` text,
  `StrengthOptional` text,
  `Color` text,
  `ColorOptional1` text,
  `ColorOptional2` text,
  `ColorOptional3` text,
  `SoilName` text,
  `SoilNameOptional` text,
  `ClassifierWeathering` text,
  `Formation` text,
  `Picture` text,
  `TCR` text,
  `RQD` text,
  `SCR` text,
  `Flag` int(11) DEFAULT NULL,
  `LastEdit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `samplingtable`
--

INSERT INTO `samplingtable` (`_ID`, `BoreholeID`, `TypeOfSampling`, `StartDepth`, `EndDepth`, `ATT`, `GeologicalClassification`, `Strength`, `StrengthOptional`, `Color`, `ColorOptional1`, `ColorOptional2`, `ColorOptional3`, `SoilName`, `SoilNameOptional`, `ClassifierWeathering`, `Formation`, `Picture`, `TCR`, `RQD`, `SCR`, `Flag`, `LastEdit`) VALUES
(12, 89, 'TW', 12, 13, '1', 'FILL', 'Very soft', 'to soft', 'Black', 'dappled', 'Brown', 'Black', 'Slightly gravelly clayey SAND', '', '0', 'SAJAHAT FORMATION', '', '', '', '', 0, '2016-01-18 21:31:31'),
(13, 90, '', 6, 10, '', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '', '', '', '', 0, '2016-01-19 19:14:39'),
(14, 5, 'high', 50, 55, '', 'often', 'in', 'ink', 'juj', 'ink', 'hi', 'hi', 'hi', 'hi', 't7tji', 'hi', 'hi', 'juj', 'it', 'hi', 0, '2017-01-18 00:37:30'),
(15, 91, 'TW', 3, 4, NULL, 'F2', 'Soft', 'to firm', 'Yellowish brown', '', '', '', 'Slightly sandy CLAY', '', '', 'KALLANG FORMATION', '', '', '', '', NULL, '2016-01-21 01:47:44'),
(16, 86, 'PS', 5, 8, NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '2016-10-11 07:20:53'),
(0, 5, '1', 1, 11, '', 'soil', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, '2017-02-01 06:53:54'),
(0, 5, '1', 1, 11, '', 'soil', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, '2017-02-01 06:53:54'),
(0, 5, '1', 1, 11, '', 'soil', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, '2017-02-01 06:53:54'),
(0, 5, '1', 1, 11, '', 'soil', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, '2017-02-01 06:53:54'),
(0, 5, '1', 1, 11, '', 'soil', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, '2017-02-01 06:53:54'),
(0, 5, '1', 1, 11, '', 'soil', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, '2017-02-01 06:53:54'),
(0, 5, '1', 1, 11, '', 'soil', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, '2017-02-01 06:53:54'),
(0, 5, '1', 1, 11, '', 'soil', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, '2017-02-01 06:53:54'),
(0, 5, '1', 1, 11, '', 'soil', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, '2017-02-01 06:53:54'),
(0, 5, '1', 1, 11, '', 'soil', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, '2017-02-01 06:53:54'),
(0, 5, '1', 1, 11, '', 'soil', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, '2017-02-01 06:53:54'),
(0, 5, '1', 1, 11, '', 'soil', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, '2017-02-01 06:53:54'),
(0, 5, '1', 1, 11, '', 'soil', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, '2017-02-01 06:53:54'),
(0, 5, '1', 1, 11, '', 'soil', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, '2017-02-01 06:53:54'),
(0, 5, '1', 1, 11, '', 'soil', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, '2017-02-01 06:53:54');