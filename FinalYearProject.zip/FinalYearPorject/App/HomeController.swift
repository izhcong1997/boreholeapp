//
//  HomeController.swift
//  LoginApp
//
//  Created by NTechnosoft on 12/01/17.
//  Copyright © 2017 NTechnosoft. All rights reserved.
//

import UIKit

class HomeController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var menuView: UIView?
    @IBOutlet weak var categories: UISegmentedControl?
    @IBOutlet weak var atableView: UITableView?
    var sample: NSArray?
    var ground: NSArray?
    var trial: NSArray?
    var insitu: NSArray?
    var display: NSArray?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        menuView?.hidden = true
        
        atableView!.estimatedRowHeight = 50.0
        atableView!.rowHeight = UITableViewAutomaticDimension
        
        display = NSArray()
        makeHTTPGetRequest()
        
  /*      let result = NSUserDefaults.standardUserDefaults().objectForKey("data")
        if result != nil {
            self.ground = result?["Get_groundtable"] as? NSArray!
            self.sample = result?["Get_samplingtable"] as? NSArray!
            self.trial = result?["Get_trialpittable"] as? NSArray!
            self.insitu = result?["Get_insitutesttable"] as? NSArray!
            self.filterAndDisplay()
        }*/
        
        // Do any additional setup after loading the view.
    }

    override func viewWillAppear(animated: Bool) {
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate?
        appDelegate?.Dict = nil
        appDelegate?.isEdit = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func Logout(sender: UIButton) {
        NSUserDefaults.standardUserDefaults().setObject(nil, forKey: "user")
        NSUserDefaults.standardUserDefaults().synchronize()
        self.navigationController?.popViewControllerAnimated(true)
    }

    
    @IBAction func showMenu(sender: UIButton) {
        menuView?.hidden = false
    }
    
    @IBAction func hideMenu(sender: UIButton) {
        menuView?.hidden = true
    }
    
    @IBAction func Sync(sender: UIBarButtonItem) {
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate?
        //makeHTTPGetRequest()
        if (appDelegate?.isConnected == true) {
            makeHTTPGetRequest()
        }else{
            Constant.sharedInstance.showAlert("Please check your internet connection", controller: self)
        }
    }
    
    @IBAction func categoryChanged(sender: UISegmentedControl) {
        filterAndDisplay()
    }
    
    func filterAndDisplay(){
        switch (self.categories?.selectedSegmentIndex)! as NSInteger {
        case 0:
            display = sample
            break
        case 1:
            display = insitu
            break
        case 2:
            display = trial
            break
        case 3:
            display = ground
            break
        default: break
            
        }
        atableView?.reloadData()
    }
    
    func makeHTTPGetRequest() {
        UIApplication.sharedApplication().networkActivityIndicatorVisible = true
        let url = NSString(format:"%@", Constant.sharedInstance.SYNC) as String
        let request = NSMutableURLRequest(URL: NSURL(string: url.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())!)!)
        
        let session = NSURLSession.sharedSession()
        
        let task = session.dataTaskWithRequest(request, completionHandler: {data, response, error -> Void in
            UIApplication.sharedApplication().networkActivityIndicatorVisible = false
            
            if(error != nil){
             /*   let result = NSUserDefaults.standardUserDefaults().objectForKey("data")
                self.ground = result?["Get_groundtable"] as? NSArray!
                self.sample = result?["Get_samplingtable"] as? NSArray!
                self.trial = result?["Get_trialpittable"] as? NSArray!
                self.insitu = result?["Get_insitutesttable"] as? NSArray!
                self.filterAndDisplay()*/
                Constant.sharedInstance.showAlert("Please check your internet connection",controller: self);
            }else{
                dispatch_async(dispatch_get_main_queue()) {
                    let result = Constant.sharedInstance.convertStringToDictionary(data!)
                    if (result != nil){
                      //  NSUserDefaults.standardUserDefaults().setObject(result, forKey: "data")
                        //NSUserDefaults.standardUserDefaults().synchronize()
                        self.ground = result?["Get_groundtable"] as? NSArray!
                        self.sample = result?["Get_samplingtable"] as? NSArray!
                        self.trial = result?["Get_trialpittable"] as? NSArray!
                        self.insitu = result?["Get_insitutesttable"] as? NSArray!
                        self.filterAndDisplay()
                    }else{
                        Constant.sharedInstance.showAlert("something went wrong.",controller: self);
                        
                    }
                }
            }
        })
        task.resume()
    }

    // MARK: - UITableView
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (display?.count)!
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(tableView: UITableView, estimatedHeightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    //As there is no table view controller, we would have to put tableviewdatasource and tableviewdelegate
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell:UITableViewCell = tableView.dequeueReusableCellWithIdentifier("cell")! as UITableViewCell
        
        cell.textLabel?.numberOfLines = 0
        
        var dictionary = display?.objectAtIndex(indexPath.row) as? NSDictionary
        
        dictionary = dictionary?.RemoveNullValueFromDic()
        //press the one of the four button and the content of that one would come out
        switch (self.categories?.selectedSegmentIndex)! as NSInteger {
        case 0://sampling
            cell.textLabel?.text =  NSString(format:"BoreholeID : %@\nType Of Sampling : %@", dictionary!["BoreholeID"] as! String,dictionary!["TypeOfSampling"] as! String) as String
            break
        case 1://insituation
            cell.textLabel?.text =  NSString(format:"BoreholeID : %@\nClassifier Weathering : %@", dictionary!["BoreholeID"] as! String,dictionary!["ClassifierWeathering"] as! String) as String
            break
        case 2://trail pit
            cell.textLabel?.text =  NSString(format:"BoreholeID : %@\nClassifier Weathering : %@", dictionary!["BoreholeID"] as! String,dictionary!["ClassifierWeathering"] as! String) as String
            break
        case 3://ground water
            cell.textLabel?.text =  NSString(format:"BoreholeID : %@\nDate : %@", dictionary!["BoreholeID"] as! String,dictionary!["Date"] as! String) as String
            break
        default: break
            
        }
        
        return cell
    }
    
//click on a cell and this table would pop up
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let alert=UIAlertController.init(title: nil, message: nil, preferredStyle: UIAlertControllerStyle.ActionSheet)
        alert.addAction(UIAlertAction.init(title: "View", style: UIAlertActionStyle.Default, handler: { (UIAlertAction) in
            self.ViewDetails(self.display?.objectAtIndex(indexPath.row) as! NSDictionary, canEdit: false)
        }))
        alert.addAction(UIAlertAction.init(title: "Edit", style: UIAlertActionStyle.Default, handler: { (UIAlertAction) in
            self.ViewDetails(self.display?.objectAtIndex(indexPath.row) as! NSDictionary, canEdit: true)
        }))
        alert.addAction(UIAlertAction.init(title: "Cancel", style: UIAlertActionStyle.Cancel, handler: { (UIAlertAction) in
            
        }))
        
        self.presentViewController(alert, animated: true) { 
            
        }
    }
    //editing the values in whatever button being tapped
    func ViewDetails(dict:NSDictionary,canEdit:Bool){
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate?
        appDelegate?.Dict = dict.RemoveNullValueFromDic()
        appDelegate?.isEdit = canEdit
        var Identifier : String?
        var viewController : UIViewController?
        switch (self.categories?.selectedSegmentIndex)! as NSInteger {
        case 0:
            Identifier = "sampling"
            viewController = self.storyboard?.instantiateViewControllerWithIdentifier(Identifier!) as! SamplingController
            break
        case 1:
            Identifier = "insitu"
            viewController = self.storyboard?.instantiateViewControllerWithIdentifier(Identifier!) as! InsituTestController
            break
        case 2:
            Identifier = "trial"
            viewController = self.storyboard?.instantiateViewControllerWithIdentifier(Identifier!) as! TrialPitController
            break
        case 3:
            Identifier = "ground"
            viewController = self.storyboard?.instantiateViewControllerWithIdentifier(Identifier!) as! BoreholeController
            break
        default: break
            
        }
        self.navigationController?.pushViewController(viewController!, animated: true)
    }
   
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension NSDictionary
{
    func RemoveNullValueFromDic()-> NSDictionary
    {
        let mutableDictionary:NSMutableDictionary = NSMutableDictionary(dictionary: self)
        for key in mutableDictionary.allKeys
        {
            if("\(mutableDictionary.objectForKey("\(key)")!)" == "<null>")
            {
                mutableDictionary.setValue("", forKey: key as! String)
            }
            else if(mutableDictionary.objectForKey("\(key)")!.isKindOfClass(NSNull))
            {
                mutableDictionary.setValue("", forKey: key as! String)
            }
            else if(mutableDictionary.objectForKey("\(key)")!.isKindOfClass(NSDictionary))
            {
                mutableDictionary.setValue(mutableDictionary.objectForKey("\(key)")!.RemoveNullValueFromDic(), forKey: key as! String)
            }
        }
        return mutableDictionary
    }
}