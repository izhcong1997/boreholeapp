//
//  BoreholeController.swift
//  LoginApp
//
//  Created by NTechnosoft on 13/01/17.
//  Copyright © 2017 NTechnosoft. All rights reserved.
//

import UIKit

class BoreholeController: UIViewController {

    @IBOutlet weak var dd: UITextField?
    @IBOutlet weak var mm: UITextField?
    @IBOutlet weak var yyyy: UITextField?
    @IBOutlet weak var time: UITextField?
    @IBOutlet weak var depth: UITextField?
    @IBOutlet weak var flag: UITextField?
    @IBOutlet weak var SAVE: UIButton?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate?
        if appDelegate?.Dict != nil {
            
//            /BoreholeID=5&Date=%@-%@-%@&Time=%@&WaterDepth=%@&Flag=%@
            let date = appDelegate?.Dict!["Date"] as? String
            
            let components = date?.componentsSeparatedByString("-")
            
            if components?.count > 0 {
                self.dd!.text = components![0]
                self.mm!.text = components![1]
                self.yyyy!.text = components![2]
            }
            
            self.flag!.text = appDelegate?.Dict!["Flag"] as? String
            self.depth!.text = appDelegate?.Dict!["WaterDepth"] as? String
            self.time!.text = appDelegate?.Dict!["Time"] as? String

            if appDelegate?.isEdit == false{
                self.SAVE?.enabled = false

                self.dd!.enabled = false
                self.mm!.enabled = false
                self.yyyy!.enabled = false
                self.flag!.enabled = false
                self.depth!.enabled = false
                self.time!.enabled = false

            }
        }

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func Back(sender: UIButton) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    @IBAction func Save(sender: UIButton) {
        if (self.dd!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter date",controller: self)
        }else if (self.mm!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter month",controller: self)
        }else if (self.yyyy!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter year",controller: self)
        }else if (self.time!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter time",controller: self)
        }else if (self.depth!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter water depth",controller: self)
        }else if (self.flag!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter flag",controller: self)
        }else{
            let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate?
            if (appDelegate?.isConnected == true) {
                makeHTTPGetRequest()
            }else{
                Constant.sharedInstance.showAlert("Please check your internet connection", controller: self)
            }
        }

    }

    func makeHTTPGetRequest() {
        UIApplication.sharedApplication().networkActivityIndicatorVisible = true
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate?
        var ID:String? = ""
        if appDelegate?.Dict != nil {
            ID = appDelegate?.Dict!["_ID"] as? String
        }
        let url = NSString(format:"%@?_ID=%@&BoreholeID=5&Date=%@-%@-%@&Time=%@&WaterDepth=%@&Flag=%@", Constant.sharedInstance.GROUND,ID!, self.dd!.text!,self.mm!.text!,self.yyyy!.text!,self.time!.text!,self.depth!.text!,self.flag!.text!) as String
        let request = NSMutableURLRequest(URL: NSURL(string: url.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())!)!)
        
        let session = NSURLSession.sharedSession()
        
        let task = session.dataTaskWithRequest(request, completionHandler: {data, response, error -> Void in
            UIApplication.sharedApplication().networkActivityIndicatorVisible = false
            
            dispatch_async(dispatch_get_main_queue()) {
                let result = Constant.sharedInstance.convertStringToDictionary(data!)
                if (result != nil){
                    let status = result?["status"] as? NSInteger!
                    if (status == 0){
                        Constant.sharedInstance.showAlert((result?["message"] as? String)!,controller: self)
                    }else{
                        
                        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate?
                        if appDelegate?.Dict != nil {
                            Constant.sharedInstance.showAlert("Added successfully",controller: self)
                            self.dd!.text = nil
                            self.mm!.text = nil
                            self.yyyy!.text = nil
                            self.flag!.text = nil
                            self.depth!.text = nil
                            self.time!.text = nil
                            
                        }else{
                            Constant.sharedInstance.showAlert("Updated successfully",controller: self)
                        }
                        
                        print(result);
                    }
                }else{
                    Constant.sharedInstance.showAlert("something went wrong.",controller: self);
                    
                }
            }
            
        })
        task.resume()
    }

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
