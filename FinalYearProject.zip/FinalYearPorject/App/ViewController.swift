//
//  ViewController.swift
//  LoginApp
//
//  Created by NTechnosoft on 31/12/16.
//  Copyright © 2016 NTechnosoft. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var username: UITextField?
    @IBOutlet weak var password: UITextField?
    
    @IBAction func Login(sender: UIButton) {
        if (self.username!.text!.isEmpty) {
            self.showAlert("Please enter username")
        }else if (self.password!.text!.isEmpty) {
            self.showAlert("Please enter password")
        }else{
            let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate?
             //makeHTTPGetRequest()
            if (appDelegate?.isConnected == true) {
                makeHTTPGetRequest()
            }else{
                Constant.sharedInstance.showAlert("Please check your internet connection", controller: self)
            }
        }
    }
    
    override func viewWillAppear(animated: Bool) {
        if (NSUserDefaults.standardUserDefaults().objectForKey("user") != nil) {
            self.performSegueWithIdentifier("Home", sender: self)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func convertStringToDictionary(data: NSData) -> [String:AnyObject]? {
            do {
                return try NSJSONSerialization.JSONObjectWithData(data, options: []) as? [String:AnyObject]
            } catch let error as NSError {
                print(error)
            }
        return nil
    }
    
   func showAlert(message: String) {
        //Create the AlertController
        let actionSheetController: UIAlertController = UIAlertController(title: "Alert", message: message, preferredStyle: .Alert)
        
        //Create and add the Cancel action
        let cancelAction: UIAlertAction = UIAlertAction(title: "Ok", style: .Cancel) { action -> Void in
            //Do some stuff
        }
        actionSheetController.addAction(cancelAction)
    
        //Present the AlertController
        self.presentViewController(actionSheetController, animated: true, completion: nil)
    }
    
    func makeHTTPGetRequest() {
        UIApplication.sharedApplication().networkActivityIndicatorVisible = true
        let url = NSString(format:"%@?username=%@&password=%@", Constant.sharedInstance.LOGIN, self.username!.text!,self.password!.text!) as String
        let request = NSMutableURLRequest(URL: NSURL(string: url.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())!)!)
        
        let session = NSURLSession.sharedSession()
        
        let task = session.dataTaskWithRequest(request, completionHandler: {data, response, error -> Void in
            UIApplication.sharedApplication().networkActivityIndicatorVisible = false
            
            dispatch_async(dispatch_get_main_queue()) {
                let result = self.convertStringToDictionary(data!)
                if (result != nil){
                    let status = result?["status"] as? NSInteger!
                    if (status == 0){
                            self.showAlert((result?["message"] as? String)!)
                    }else{
                        print(result);
                        NSUserDefaults.standardUserDefaults().setObject(result?["Get_data"]?.objectAtIndex(0), forKey: "user")
                        NSUserDefaults.standardUserDefaults().synchronize()
                        self.performSegueWithIdentifier("Home", sender: self)
                        self.username!.text = ""
                        self.password!.text = ""
                    }
                }else{
                        self.showAlert("something went wrong.");
                    
                }
            }
            
        })
        task.resume()
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {   //delegate method
        textField.resignFirstResponder()
        
        return true
    }

}

