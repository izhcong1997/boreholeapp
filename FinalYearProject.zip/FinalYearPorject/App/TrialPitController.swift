//
//  TrialPitController.swift
//  LoginApp
//
//  Created by NTechnosoft on 13/01/17.
//  Copyright © 2017 NTechnosoft. All rights reserved.
//

import UIKit

class TrialPitController: UIViewController {

    @IBOutlet weak var type: UITextField?
    @IBOutlet weak var start: UITextField?
    @IBOutlet weak var end: UITextField?
    @IBOutlet weak var geological: UITextField?
    @IBOutlet weak var strength: UITextField?
    @IBOutlet weak var strength1: UITextField?
    @IBOutlet weak var color: UITextField?
    @IBOutlet weak var color1: UITextField?
    @IBOutlet weak var color2: UITextField?
    @IBOutlet weak var color3: UITextField?
    @IBOutlet weak var soil: UITextField?
    @IBOutlet weak var soil1: UITextField?
    @IBOutlet weak var weather: UITextField?
    @IBOutlet weak var formation: UITextField?
    @IBOutlet weak var flag: UITextField?
    @IBOutlet weak var SAVE: UIButton?

    override func viewDidLoad() {
        super.viewDidLoad()
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate?
        if appDelegate?.Dict != nil {
            self.type!.text = ""//appDelegate?.Dict![""] as? String
            self.start!.text = appDelegate?.Dict!["StartDepth"] as? String
            self.end!.text = appDelegate?.Dict!["EndDepth"] as? String
            self.geological!.text = appDelegate?.Dict!["GeologicalClassification"] as? String
            self.strength!.text = appDelegate?.Dict!["Strength"] as? String
            self.strength1!.text = appDelegate?.Dict!["StrengthOptional"] as? String
            self.color!.text = appDelegate?.Dict!["Color"] as? String
            self.color1!.text = appDelegate?.Dict!["ColorOptional1"] as? String
            self.color2!.text = appDelegate?.Dict!["ColorOptional2"] as? String
            self.color3!.text = appDelegate?.Dict!["ColorOptional3"] as? String
            self.soil!.text = appDelegate?.Dict!["SoilName"] as? String
            self.soil1!.text = appDelegate?.Dict!["SoilNameOptional"] as? String
            self.weather!.text = appDelegate?.Dict!["ClassifierWeathering"] as? String
            self.formation!.text = appDelegate?.Dict!["Formation"] as? String
            self.flag!.text = appDelegate?.Dict!["Flag"] as? String

            //TypeOfSampling=%@&StartDepth=%@&EndDepth=%@&ATT=%@&GeologicalClassification=%@&Strength=%@&StrengthOptional=%@&Color=%@&ColorOptional1=%@&ColorOptional2=%@&ColorOptional3=%@&SoilName=%@&SoilNameOptional=%@&ClassifierWeathering=%@&Formation=%@&Flag=%@
            
            if appDelegate?.isEdit == false{
                self.SAVE?.enabled = false

                self.type!.enabled = false
                self.start!.enabled = false
                self.end!.enabled = false
                self.geological!.enabled = false
                self.strength!.enabled = false
                self.strength1!.enabled = false
                self.color!.enabled = false
                self.color1!.enabled = false
                self.color2!.enabled = false
                self.color3!.enabled = false
                self.soil!.enabled = false
                self.soil1!.enabled = false
                self.weather!.enabled = false
                self.formation!.enabled = false
                self.flag!.enabled = false

            }
        }

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func Back(sender: UIButton) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    @IBAction func Save(sender: UIButton) {
        if (self.type!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter Type of sampling",controller: self)
        }else if (self.start!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter start depth",controller: self)
        }else if (self.end!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter end depth",controller: self)
        }else if (self.geological!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter Geological Classification",controller: self)
        }else if (self.strength!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter Strength",controller: self)
        }else /*if (self.strength1!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter Strength Optional",controller: self)
        }else*/ if (self.color!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter Color",controller: self)
        }else /*if (self.color1!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter Color1",controller: self)
        }else if (self.color2!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter Color2",controller: self)
        }else if (self.color3!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter Color3",controller: self)
        }else */if (self.soil!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter Soil Name",controller: self)
        }else /*if (self.soil1!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter Soil Name Optional",controller: self)
        }else if (self.weather!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter Classifier Weather",controller: self)
        }else if (self.formation!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter Formation",controller: self)
        }else*/ if (self.flag!.text!.isEmpty) {
            Constant.sharedInstance.showAlert("Please enter FLAG",controller: self)
        }else{
            let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate?
            if (appDelegate?.isConnected == true) {
                makeHTTPGetRequest()
            }else{
                Constant.sharedInstance.showAlert("Please check your internet connection", controller: self)
            }
        }
        
    }
    
    func makeHTTPGetRequest() {
        let att = ""
        UIApplication.sharedApplication().networkActivityIndicatorVisible = true
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate?
        var ID:String? = ""
        if appDelegate?.Dict != nil {
            ID = appDelegate?.Dict!["_ID"] as? String
        }
        let url = NSString(format:"%@?_ID=%@&BoreholeID=5&TypeOfSampling=%@&StartDepth=%@&EndDepth=%@&ATT=%@&GeologicalClassification=%@&Strength=%@&StrengthOptional=%@&Color=%@&ColorOptional1=%@&ColorOptional2=%@&ColorOptional3=%@&SoilName=%@&SoilNameOptional=%@&ClassifierWeathering=%@&Formation=%@&Flag=%@", Constant.sharedInstance.TRIAL,ID!, self.type!.text!,self.start!.text!,self.end!.text!,att,self.geological!.text!,self.strength!.text!,self.strength1!.text!,self.color!.text!,self.color1!.text!,self.color2!.text!,self.color3!.text!,self.soil!.text!,self.soil1!.text!,self.weather!.text!,self.formation!.text!,self.flag!.text!) as String
        let request = NSMutableURLRequest(URL: NSURL(string: url.stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet())!)!)
        
        let session = NSURLSession.sharedSession()
        
        let task = session.dataTaskWithRequest(request, completionHandler: {data, response, error -> Void in
            UIApplication.sharedApplication().networkActivityIndicatorVisible = false
            
            dispatch_async(dispatch_get_main_queue()) {
                let result = Constant.sharedInstance.convertStringToDictionary(data!)
                if (result != nil){
                    let status = result?["status"] as? NSInteger!
                    if (status == 0){
                        Constant.sharedInstance.showAlert((result?["message"] as? String)!,controller: self)
                    }else{
                        
                        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate?
                        if appDelegate?.Dict != nil {
                            Constant.sharedInstance.showAlert("Added successfully",controller: self)
                            self.type!.text = nil
                            self.start!.text = nil
                            self.end!.text = nil
                            self.geological!.text = nil
                            self.strength!.text = nil
                            self.strength1!.text = nil
                            self.color!.text = nil
                            self.color1!.text = nil
                            self.color2!.text = nil
                            self.color3!.text = nil
                            self.soil!.text = nil
                            self.soil1!.text = nil
                            self.weather!.text = nil
                            self.formation!.text = nil
                            self.flag!.text = nil

                        }else{
                            Constant.sharedInstance.showAlert("Updated successfully",controller: self)
                        }
                        
                    }
                }else{
                    Constant.sharedInstance.showAlert("something went wrong.",controller: self);
                    
                }
            }
            
        })
        task.resume()
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
