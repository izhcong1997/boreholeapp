//
//  Constant.swift
//  LoginApp
//
//  Created by NTechnosoft on 12/01/17.
//  Copyright © 2017 NTechnosoft. All rights reserved.
//

import UIKit

class Constant: NSObject {

    static let sharedInstance = Constant()
    
    var LOGIN = "http://localhost:8888/DEMO_TEST/login.php"
    var SYNC = "http://localhost:8888/DEMO_TEST/get_data.php"
    var GROUND = "http://localhost:8888/DEMO_TEST/insert_groundtable.php"
    var SAMPLE = "http://localhost:8888/DEMO_TEST/insert_samplingtable.php"
    var INSITU = "http://localhost:8888/DEMO_TEST/insert_insitutesttable.php"
    var TRIAL = "http://localhost:8888/DEMO_TEST/insert_trialpittable.php"
    
    func convertStringToDictionary(data: NSData) -> [String:AnyObject]? {
        do {
            return try NSJSONSerialization.JSONObjectWithData(data, options: []) as? [String:AnyObject]
        } catch let error as NSError {
            print(error)
        }
        return nil
    }
    
    func showAlert(message: String, controller:UIViewController) {
        //Create the AlertController
        let actionSheetController: UIAlertController = UIAlertController(title: "Alert", message: message, preferredStyle: .Alert)
        
        //Create and add the Cancel action
        let cancelAction: UIAlertAction = UIAlertAction(title: "Ok", style: .Cancel) { action -> Void in
            //Do some stuff
        }
        actionSheetController.addAction(cancelAction)
        
        //Present the AlertController
        controller.presentViewController(actionSheetController, animated: true, completion: nil)
    }


}
