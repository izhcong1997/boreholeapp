<?php
include('db_conn.php');
error_reporting(0);

$json_location['Get_groundtable'] = array();
$json_location['Get_insitutesttable'] = array();
$json_location['Get_samplingtable'] = array();
$json_location['Get_trialpittable'] = array();

 $dataa="select * from groundtable";
	$data_of=mysql_query($dataa);
		
		while($data_of_data =mysql_fetch_assoc($data_of)){
		$json_location['Get_groundtable'][] = $data_of_data;
			}
			
			$dataa1="select * from insitutesttable";
	$data_of1=mysql_query($dataa1);
		
		while($data_of_data1 =mysql_fetch_assoc($data_of1)){
		$json_location['Get_insitutesttable'][] = $data_of_data1;
			}
			
			$dataa2="select * from samplingtable";
	$data_of2=mysql_query($dataa2);
		
		while($data_of_data2 =mysql_fetch_assoc($data_of2)){
		$json_location['Get_samplingtable'][] = $data_of_data2;
			}
			
			$dataa3="select * from trialpittable";
	$data_of3=mysql_query($dataa3);
		
		while($data_of_data3 =mysql_fetch_assoc($data_of3)){
		$json_location['Get_trialpittable'][] = $data_of_data3;
			}
	
	echo json_encode($json_location);
	
	
?>