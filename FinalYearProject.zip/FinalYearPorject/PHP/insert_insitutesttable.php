<?php   
include('db_conn.php');
error_reporting(0);
$sql = "";
	
if($_REQUEST['_ID'] == ""){
	$sql = "insert into insitutesttable set BoreholeID='".mysql_real_escape_string($_REQUEST['BoreholeID'])."',TypeOfTest='".mysql_real_escape_string($_REQUEST['TypeOfTest'])."',TestNumber='".mysql_real_escape_string($_REQUEST['TestNumber'])."',StartDepth='".mysql_real_escape_string($_REQUEST['StartDepth'])."',EndDepth='".mysql_real_escape_string($_REQUEST['EndDepth'])."',n1values='".mysql_real_escape_string($_REQUEST['n1values'])."',n2values='".mysql_real_escape_string($_REQUEST['n2values'])."',n3values='".mysql_real_escape_string($_REQUEST['n3values'])."',n4values='".mysql_real_escape_string($_REQUEST['n4values'])."',n5values='".mysql_real_escape_string($_REQUEST['n5values'])."',n6values='".mysql_real_escape_string($_REQUEST['n6values'])."',Nvalue='".mysql_real_escape_string($_REQUEST['Nvalue'])."',PenetrationDepth='".mysql_real_escape_string($_REQUEST['PenetrationDepth'])."',GeologicalClassification='".mysql_real_escape_string($_REQUEST['GeologicalClassification'])."',Strength='".mysql_real_escape_string($_REQUEST['Strength'])."',StrengthOptional='".mysql_real_escape_string($_REQUEST['StrengthOptional'])."',Color='".mysql_real_escape_string($_REQUEST['Color'])."',ColorOptional1='".mysql_real_escape_string($_REQUEST['ColorOptional1'])."',ColorOptional2='".mysql_real_escape_string($_REQUEST['ColorOptional2'])."',ColorOptional3='".mysql_real_escape_string($_REQUEST['ColorOptional3'])."',SoilName='".mysql_real_escape_string($_REQUEST['SoilName'])."',SoilNameOptional='".mysql_real_escape_string($_REQUEST['SoilNameOptional'])."',ClassifierWeathering='".mysql_real_escape_string($_REQUEST['ClassifierWeathering'])."',Formation='".mysql_real_escape_string($_REQUEST['Formation'])."',Picture='".mysql_real_escape_string($_REQUEST['Picture'])."',Remoulded='".mysql_real_escape_string($_REQUEST['Remoulded'])."',Undisturbed='".mysql_real_escape_string($_REQUEST['Undisturbed'])."',Flag='".mysql_real_escape_string($_REQUEST['Flag'])."'";
}else{
	$sql = "UPDATE insitutesttable set BoreholeID='".mysql_real_escape_string($_REQUEST['BoreholeID'])."',TypeOfTest='".mysql_real_escape_string($_REQUEST['TypeOfTest'])."',TestNumber='".mysql_real_escape_string($_REQUEST['TestNumber'])."',StartDepth='".mysql_real_escape_string($_REQUEST['StartDepth'])."',EndDepth='".mysql_real_escape_string($_REQUEST['EndDepth'])."',n1values='".mysql_real_escape_string($_REQUEST['n1values'])."',n2values='".mysql_real_escape_string($_REQUEST['n2values'])."',n3values='".mysql_real_escape_string($_REQUEST['n3values'])."',n4values='".mysql_real_escape_string($_REQUEST['n4values'])."',n5values='".mysql_real_escape_string($_REQUEST['n5values'])."',n6values='".mysql_real_escape_string($_REQUEST['n6values'])."',Nvalue='".mysql_real_escape_string($_REQUEST['Nvalue'])."',PenetrationDepth='".mysql_real_escape_string($_REQUEST['PenetrationDepth'])."',GeologicalClassification='".mysql_real_escape_string($_REQUEST['GeologicalClassification'])."',Strength='".mysql_real_escape_string($_REQUEST['Strength'])."',StrengthOptional='".mysql_real_escape_string($_REQUEST['StrengthOptional'])."',Color='".mysql_real_escape_string($_REQUEST['Color'])."',ColorOptional1='".mysql_real_escape_string($_REQUEST['ColorOptional1'])."',ColorOptional2='".mysql_real_escape_string($_REQUEST['ColorOptional2'])."',ColorOptional3='".mysql_real_escape_string($_REQUEST['ColorOptional3'])."',SoilName='".mysql_real_escape_string($_REQUEST['SoilName'])."',SoilNameOptional='".mysql_real_escape_string($_REQUEST['SoilNameOptional'])."',ClassifierWeathering='".mysql_real_escape_string($_REQUEST['ClassifierWeathering'])."',Formation='".mysql_real_escape_string($_REQUEST['Formation'])."',Picture='".mysql_real_escape_string($_REQUEST['Picture'])."',Remoulded='".mysql_real_escape_string($_REQUEST['Remoulded'])."',Undisturbed='".mysql_real_escape_string($_REQUEST['Undisturbed'])."',Flag='".mysql_real_escape_string($_REQUEST['Flag'])."' WHERE _ID='".$_REQUEST['_ID']."'";
}
	$sql_req =mysql_query($sql);
	if($sql_req==true)
	{

	$json['status'] = 1;
	$json['msg'] = 'Done';
	echo json_encode($json);
	}
	else
	{
		$json['status'] = 0;
		$json['msg'] = 'Server Problem';
		echo json_encode($json);
	}
	
	
?>