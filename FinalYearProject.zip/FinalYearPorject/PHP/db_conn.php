<?php 
$dbhost='localhost';
$dbuser='root';
$dbpass='root';
$conn=mysql_connect($dbhost, $dbuser,$dbpass)or die('Could not connect to mysql');
$db='entries';
mysql_select_db($db);


mysql_set_charset('utf8');
mysql_query("SET NAMES 'utf8");



?>