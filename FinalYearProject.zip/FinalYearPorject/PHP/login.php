<?php
$dbhost='localhost';
$dbuser='root';
$dbpass='root';
$conn=mysql_connect($dbhost, $dbuser,$dbpass)or die('Could not connect to mysql');
$db='table';
mysql_select_db($db);


mysql_set_charset('utf8');
mysql_query("SET NAMES 'utf8");

//error_reporting(0);

//$password = md5($_REQUEST['password']);

	if(!isset($_REQUEST['username']) || strlen($_REQUEST['username']) == 0){
	$json['status'] = 0;
	$json['message'] = "username is missing";
	echo json_encode($json);
	die();
	}
	
	if(!isset($_REQUEST['password']) || strlen($_REQUEST['password']) == 0){
	$json['status'] = 0;
	$json['message'] = "password is missing";
	echo json_encode($json);
	die();
	}	
	
	$json_location['Get_data'] = array();
	
	
	
	$sql_users_checked = mysql_query("select * from user where username='".$_REQUEST['username']."' and password='".$_REQUEST['password']."'");
	if(mysql_num_rows($sql_users_checked)>0)
	{
		$sql_users_data=mysql_fetch_assoc($sql_users_checked);
		
			$sql_data_qu = mysql_query("select * from user where intid='".$sql_users_data['intid']."'");
		if(mysql_num_rows($sql_data_qu)>0)
		{
	
			$sql_data=mysql_fetch_assoc($sql_data_qu);
			
				$json_location['Get_data'][] = $sql_data;
				$json_location['status'] = 1;
				$json_location['message'] = 'login successfully.';
				echo json_encode($json_location);
				die();
		}
		else
		{	   
				$json_location['status'] = 0;
				$json_location['message'] = 'Server problem. Try after sometime.';
				echo json_encode($json_location);
				die();	
		}
	}
	else
	{
				$json_location['status'] = 0;
				$json_location['users'] = mysql_num_rows($sql_users_checked);
				$json_location['sql'] = "select * from user where username='".$_REQUEST['username']."' and password='".$_REQUEST['password']."'";
				$json_location['message'] = "username or password doesn't matched";
				echo json_encode($json_location);
				die();		
	}
	
?>