<?php   
include('db_conn.php');
error_reporting(0);

$sql = "";
	
if($_REQUEST['_ID'] == ""){
	$sql = "insert into samplingtable set BoreholeID='".mysql_real_escape_string($_REQUEST['BoreholeID'])."',TypeOfSampling='".mysql_real_escape_string($_REQUEST['TypeOfSampling'])."',StartDepth='".mysql_real_escape_string($_REQUEST['StartDepth'])."',EndDepth='".mysql_real_escape_string($_REQUEST['EndDepth'])."',ATT='".mysql_real_escape_string($_REQUEST['ATT'])."',GeologicalClassification='".mysql_real_escape_string($_REQUEST['GeologicalClassification'])."',Strength='".mysql_real_escape_string($_REQUEST['Strength'])."',StrengthOptional='".mysql_real_escape_string($_REQUEST['StrengthOptional'])."',Color='".mysql_real_escape_string($_REQUEST['Color'])."',ColorOptional1='".mysql_real_escape_string($_REQUEST['ColorOptional1'])."',ColorOptional2='".mysql_real_escape_string($_REQUEST['ColorOptional2'])."',ColorOptional3='".mysql_real_escape_string($_REQUEST['ColorOptional3'])."',SoilName='".mysql_real_escape_string($_REQUEST['SoilName'])."',SoilNameOptional='".mysql_real_escape_string($_REQUEST['SoilNameOptional'])."',ClassifierWeathering='".mysql_real_escape_string($_REQUEST['ClassifierWeathering'])."',Formation='".mysql_real_escape_string($_REQUEST['Formation'])."',Picture='".mysql_real_escape_string($_REQUEST['Picture'])."',TCR='".mysql_real_escape_string($_REQUEST['TCR'])."',RQD='".mysql_real_escape_string($_REQUEST['RQD'])."',SCR='".mysql_real_escape_string($_REQUEST['SCR'])."',Flag='".mysql_real_escape_string($_REQUEST['Flag'])."'";
}else{
	$sql = "UPDATE samplingtable set BoreholeID='".mysql_real_escape_string($_REQUEST['BoreholeID'])."',TypeOfSampling='".mysql_real_escape_string($_REQUEST['TypeOfSampling'])."',StartDepth='".mysql_real_escape_string($_REQUEST['StartDepth'])."',EndDepth='".mysql_real_escape_string($_REQUEST['EndDepth'])."',ATT='".mysql_real_escape_string($_REQUEST['ATT'])."',GeologicalClassification='".mysql_real_escape_string($_REQUEST['GeologicalClassification'])."',Strength='".mysql_real_escape_string($_REQUEST['Strength'])."',StrengthOptional='".mysql_real_escape_string($_REQUEST['StrengthOptional'])."',Color='".mysql_real_escape_string($_REQUEST['Color'])."',ColorOptional1='".mysql_real_escape_string($_REQUEST['ColorOptional1'])."',ColorOptional2='".mysql_real_escape_string($_REQUEST['ColorOptional2'])."',ColorOptional3='".mysql_real_escape_string($_REQUEST['ColorOptional3'])."',SoilName='".mysql_real_escape_string($_REQUEST['SoilName'])."',SoilNameOptional='".mysql_real_escape_string($_REQUEST['SoilNameOptional'])."',ClassifierWeathering='".mysql_real_escape_string($_REQUEST['ClassifierWeathering'])."',Formation='".mysql_real_escape_string($_REQUEST['Formation'])."',Picture='".mysql_real_escape_string($_REQUEST['Picture'])."',TCR='".mysql_real_escape_string($_REQUEST['TCR'])."',RQD='".mysql_real_escape_string($_REQUEST['RQD'])."',SCR='".mysql_real_escape_string($_REQUEST['SCR'])."',Flag='".mysql_real_escape_string($_REQUEST['Flag'])."' WHERE _ID='".$_REQUEST['_ID']."'";
}
	$sql_req =mysql_query($sql);
	if($sql_req==true)
	{

	$json['status'] = 1;
	$json['msg'] = 'Done';
	echo json_encode($json);
	}
	else
	{
		$json['status'] = 0;
		$json['msg'] = 'Server Problem';
		echo json_encode($json);
	}
	
	
?>